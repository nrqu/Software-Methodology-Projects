package LibrarySystem;
/**
 * This class is used as a driver class to run the Kiosk class.
 * @author HECTOR CERDA, LUIS FIGUEROAGIL
 *
 */
public class RunProject1 {
	/**
	 * Method used to call the interface method in the Kiosk Class.
	 */
	public static void main(String[] args) {
		new Kiosk().run();
	}
}
